<?php
defined( 'ABSPATH' ) || die;

use MetaBox\Support\Arr;

/**
 * No longer needed. Keep it here for backward compatibility.
 */
class RWMB_Helpers_Array extends Arr {}
